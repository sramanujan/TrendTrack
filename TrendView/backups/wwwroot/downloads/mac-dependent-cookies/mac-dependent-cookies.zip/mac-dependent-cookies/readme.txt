=== MAC Dependent Cookies ===
Contributors: StubHorn (and Ip dependent cookies)
Tags: cookies, safety, auth, security
Requires at least: 2.9
Tested up to: 3.2.1
Stable tag:

Plugin MAC Dependent Cookies makes your Wordpress installation more secure adding your MAC to salt (which makes cookies MAC-dependent).

== Description ==

Each time you login to your blog WordPress creates a session cookie which is used to authenticate you.
By default if someone somehow gets your cookies he (or she) is able to use them to compromise your blog
(even without having to know your password!). To prevent this you may want to make your auth cookies mac-dependent so that they could be valid only for that MAC which you used during login.

== Installation ==

To install the plugin follow these steps :

   1. Download the mac-dependent-cookies.zip file to your local machine.
   1. Unzip the file
   1. Upload "mac-dependent-cookies" folder to the "/wp-content/plugins/" directory
   1. Activate the plugin through the 'Plugins' menu in WordPress
   1. Go to plugin settings and enable the plugin.
   1. You will be prompted to log in again. Do so. This is necessary to set the new cookie.

== Changelog ==
0.1 

Used ip-dependent-cookies to come up with this, which uses mac instead of ip..
