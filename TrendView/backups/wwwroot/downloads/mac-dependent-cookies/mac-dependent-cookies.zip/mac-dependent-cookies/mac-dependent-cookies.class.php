<?php

class IPDependentCookies {
	var $remote_addr;
	var $nonce;
	var $options;

    function IPDependentCookies(){
		/*
		$plugin_active = get_option('ip_dependent_cookies_active');
		if ($plugin_active !== false) {
			$this->remote_addr = get_option('ip_dependent_cookies_remote_addr');
			if ($this->remote_addr === false)
				$this->remote_addr = "";
		}
		*/
		add_filter('salt', array(&$this, 'ip_salt'), 10, 2);
		add_action('admin_menu', array(&$this, 'config_page'));
		
		if ( !function_exists('wp_nonce_field') ) {
			$this->nonce = -1;
		} else {
			$this->nonce = 'ipdc-update-key';
		}
		$this->options = get_option('ipdc_options');
		
		if (!isset($this->options) || ($this->options === FALSE)) {
			$this->options = array();
			$this->options['ipdc_enabled'] = 0;
			$this->options['ipdc_forwarded'] = false;
		}
		add_filter( 'plugin_action_links', array( &$this, 'plugin_action_links' ), 10, 2 );
		$this->register_admin_notices();
    }
	
	function nonce_field($action = -1) {
		return wp_nonce_field($action);
	}

    function ip_salt($salt, $scheme)
	{
		if (!$this->options['ipdc_enabled']) return $salt;
		if ($this->options['ipdc_forwarded'] && isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			$used = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else
			$used = $_SERVER['REMOTE_ADDR'];
			
		// Get the arp executable path 
		$location = `which arp`; 
		// Execute the arp command and store the output in $arpTable 
		$arpTable = `$location`; 
		// Split the output so every line is an entry of the $arpSplitted array 
		$arpSplitted = split("\n",$arpTable); 
		// Get the remote ip address (the ip address of the client, the browser) 
		$remoteIp = $used; 
		// Cicle the array to find the match with the remote ip address 
		foreach ($arpSplitted as $value) 
		{ 
			// Split every arp line, this is done in case the format of the arp 
			// command output is a bit different than expected 
			$valueSplitted = split(" ",$value); 
			foreach ($valueSplitted as $spLine) 
			{ 
				if (preg_match("/$remoteIp/",$spLine)) 
				{ 
					$ipFound = true; 
				} 
				// The ip address has been found, now rescan all the string 
				// to get the mac address 
				if ($ipFound) 
				{ 
					// Rescan all the string, in case the mac address, in the string 
					// returned by arp, comes before the ip address 
					// (you know, Murphy's laws) 
					reset($valueSplitted); 
					foreach ($valueSplitted as $spLine) 
					{ 
						if (preg_match("/[0-9a-f][0-9a-f][:-]". 
						"[0-9a-f][0-9a-f][:-]". 
						"[0-9a-f][0-9a-f][:-]". 
						"[0-9a-f][0-9a-f][:-]". 
						"[0-9a-f][0-9a-f][:-]". 
						"[0-9a-f][0-9a-f]/i",$spLine)) 
						{ 
							return $spLine.$salt; 
						} 
					} 
				} 
				$ipFound = false; 
			} 
		} 
		return $salt; 
			
    }

	function plugin_not_active(){
		if ( ! $this->options['ipdc_enabled'] ) {
			echo '<div id="ipdc-nag" class="updated fade">
			   To start using <strong>MAC Dependent Cookies</strong> you need to enable the plugin in its settings! <a href="' .
			   IPDC_PLUGIN_SETTINGS_URL .
			   '">Go to configuration</a>.
			</div>';
		}
	}

	function register_admin_notices() {
		add_action( 'admin_notices', array( &$this, 'plugin_not_active' ) );
	}

	function plugin_action_links( $links, $file ) {
		if ( $file != IPDC_PLUGIN_BASENAME )
			return $links;

		$settings_link = '<a href="' . esc_url( IPDC_PLUGIN_SETTINGS_URL ) . '">'
			. esc_html( __( 'Settings', 'ipdc' ) ) . '</a>';

		array_unshift( $links, $settings_link );

		return $links;
	}

    function config_page(){
		if ( function_exists('add_submenu_page') )
			add_submenu_page( IPDC_PLUGIN_MENU_PARENT, 'IP Dependent Cookies',
				'IP Dependent Cookies', 'manage_options', IPDC_PLUGIN_FULL_PATH, array(&$this,'conf_page'));
    }

    function conf_page() {
		$message = NULL;
		if ( function_exists('current_user_can') && !current_user_can('manage_options') )
			die(__('Cheatin&#8217; uh?'));

		if (isset($_POST['action']) && $_POST['action'] == 'ipdc_update' && isset($_POST['Submit'])) {
			$message = 'MAC Dependent Cookies settings updated. Please <a href="' . wp_login_url(wp_get_referer(), false) . '">log in</a> again.';
			$nonce = $_POST['nonce-ipdc'];
			if (!wp_verify_nonce($nonce, 'ipdc-nonce'))
				die ('Security Check - If you receive this in error, log out and back in to WordPress');
			$this->options = array();
			$this->options['ipdc_enabled'] = $_POST['ipdc_enabled'];
			$this->options['ipdc_forwarded'] = isset($_POST['ipdc_forwarded']);
			update_option('ipdc_options', $this->options);
		}
		
		if ($message){
			echo "<div id=\"message\" class=\"updated fade\"><p>$message</p></div>";
		}
?>
<div class="wrap">
		
		<h2>MAC Dependent Cookies Options</h2>
<p><strong>NB</strong>: After changing any of these options you will be forced to log in to WordPress again!</p>
<script type="text/javascript">
<!--
    function toggleVisibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
//-->
</script>
<h3>Click on the option titles to get help!</h3>

<form name="dofollow" action="" method="post">
<table class="form-table">

<tbody><tr>
<th scope="row" style="text-align: right; vertical-align: top;">
<a style="cursor: pointer;" title="Click for Help!" onclick="toggleVisibility('ipdc_enabled_tip');">
Plugin Status:</a>

</th><td>
<input name="ipdc_enabled" value="1" <?php if ($this->options['ipdc_enabled'] == 1) echo 'checked="checked")';?> type="radio"> Enabled<br>
<input name="ipdc_enabled" value="0" <?php if ($this->options['ipdc_enabled'] == 0) echo 'checked="checked")';?> type="radio"> Disabled

<div style="max-width: 500px; text-align: left; display: none;" id="ipdc_enabled_tip">
MAC Dependent Cookies must be enabled for use.</div>
</td>
</tr>

<tr>
<th scope="row" style="text-align: right; vertical-align: top;">
<a style="cursor: pointer;" title="Click for Help!" onclick="toggleVisibility('ipdc_forwarded_tip');">
MAC Address of FORWARDED in place of REMOTE-ADDR:</a>

</th><td>
<input name="ipdc_forwarded" <?php if ($this->options['ipdc_forwarded']) echo 'checked="1"';?> type="checkbox">
<div style="max-width: 500px; text-align: left; display: none;" id="ipdc_forwarded_tip">
Turn on this option if your http-server is behind frontend server.</div>
</td>
</tr>

</tbody></table>
<p class="submit">
<input name="action" value="ipdc_update" type="hidden"> 
<input type="hidden" name="nonce-ipdc" value="<?php echo wp_create_nonce('ipdc-nonce'); ?>" />
<input name="page_options" value="ipdc_home_description" type="hidden"> 
<input class="button-primary" name="Submit" value="Update Options »" type="submit"> 
</p>

<p>
</div>
<?php
    }
}
